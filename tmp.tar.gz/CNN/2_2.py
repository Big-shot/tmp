import numpy as np
from keras import layers
from keras.layers import Input, Dense, Activation, ZeroPadding2D, BatchNormalization, Flatten, Conv2D
from keras.layers import AveragePooling2D, MaxPooling2D, Dropout, GlobalMaxPool2D, GlobalAveragePooling2D
from keras.models import Model
from keras.preprocessing import image
from keras.utils import layer_utils
from keras.utils.data_utils import get_file
from keras.applications.imagenet_utils import preprocess_input
import pydot
from IPython.display import SVG
from keras.utils.vis_utils import model_to_dot
from keras.utils import plot_model
from kt_utils import *

import keras.backend as K
K.set_image_data_format('channels_last')
import matplotlib.pyplot as plt
from matplotlib.pyplot import imshow 

# 载入数据
X_train_orig, Y_train_orig, X_test_orig, Y_test_orig, classes = load_dataset()

# 归一化数据
X_train = X_train_orig / 255.
X_test = X_test_orig / 255.

Y_train = Y_train_orig.T
Y_test = Y_test_orig.T

# print('number of training example:',X_train.shape[0])
# print('number of test example:',X_test.shape[0])
# print('X_train shape:',X_train.shape)
# print('X_test shape:',X_test.shape)
# print('Y_train shape:',Y_train.shape)
# print('Y_test shape:',Y_test.shape)
# 
# #显示指定样本图像和标记
# index=4
# plt.imshow(X_train_orig[index])
# plt.show()
# print('y=',Y_train[index])


# Set a simple keras model
def model(input_shape):
    X_input = Input(input_shape)
    
    # pads the border of X_input with zeros
    X = ZeroPadding2D((3, 3))(X_input)  # height-3,weight-3
    
    # conv->BN->RELU Block applied
    X = Conv2D(32, (7, 7), strides=(1, 1), name='conv0')(X)
    X = BatchNormalization(axis=3, name='bn0')
    X = Activation('relu')(X)
    
    # Maxpool
    X = MaxPooling2D((2, 2), name='max_pool')(X)
    
    # Flatten X+Fullyconnection
    X = Flatten()(X)
    X = Dense(1, activation='sigmoid', name='fc')(X)
    
    # creat model
    model = Model(inputs=X_input, output=X, name='HappyModel')
    
    return model


def Happyhouse(input_shape):
    # Define the input placeholder as a tensor
    X_input = Input(input_shape)
    
    # Zero-Padding shape=(f=3,f=3)
    X = ZeroPadding2D((3, 3))(X_input)
    
    # CONV2D->BN->RELU
    X = Conv2D(32, (7, 7), strides=(1, 1), name='conv0')(X)
    X = BatchNormalization(axis=3, name='bn0')(X)
    X = Activation('relu')(X)
    
    # Maxpooling
    X = MaxPooling2D((2, 2), name='max_pool')(X)
    
    # Flatten + Fullyconnection
    X = Flatten()(X)
    X = Dense(1, activation='sigmoid', name='fc')(X)
    
    # create model
    model = Model(inputs=X_input, outputs=X, name='HappyModel')
    
    return model
    

# Exercise
HappyModel = Happyhouse(X_train.shape[1:])
# Configure the model
HappyModel.compile(optimizer='Adam', loss='binary_crossentropy', metrics=['accuracy'])
# Trian the model on train data
HappyModel.fit(X_train, Y_train, epochs=10, batch_size=32)
# evaluate the model
score = HappyModel.evaluate(X_test, Y_test)
print()
print('The loss =', score[0])
print('Accuracy=', score[1])

# Test my picture
img_path = 'mygirl.jpg'
img = image.image.load_img(img_path, target_size=(64, 64))
imshow(img)
plt.show()
x = image.img_to_array(img)  # image->array
x = np.expand_dims(x, axis=0)  # expand x.shape->(1,n_H,n_W,n_C)
x = preprocess_input(x)  

# Print the result
y = HappyModel.predict(x)
if y == [1.]:
    print('The person is happy!')
elif y == [0.]:
    print('The person is not happy.')

'''
Created on 2019年3月18日

@author: Administrator
'''
